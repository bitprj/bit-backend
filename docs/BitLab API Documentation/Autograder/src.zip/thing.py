# Multiply only using addition

def mult_add(num1, num2):
    return num1 * num2
